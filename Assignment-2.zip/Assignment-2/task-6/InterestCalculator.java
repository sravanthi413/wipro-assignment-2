public class InterestCalculator {
    public static void main(String[] args) {
        // Check if the number of command line arguments is correct
        if (args.length != 2) {
            System.out.println("Please provide exactly two arguments: <gender> <age>");
            return;
        }

        String gender = args[0];
        int age;

        try {
            age = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            System.out.println("Please provide a valid age.");
            return;
        }

        // Determine the interest rate based on gender and age
        double interestRate = getInterestRate(gender, age);

        if (interestRate == -1) {
            System.out.println("Invalid input. Please ensure the gender is 'Male' or 'Female' and the age is between 1 and 100.");
        } else {
            System.out.println("The percentage of interest is: " + interestRate + "%");
        }
    }

    private static double getInterestRate(String gender, int age) {
        if (gender.equalsIgnoreCase("Female")) {
            if (age >= 1 && age <= 58) {
                return 8.2;
            } else if (age >= 59 && age <= 100) {
                return 9.2;
            }
        } else if (gender.equalsIgnoreCase("Male")) {
            if (age >= 1 && age <= 58) {
                return 8.4;
            } else if (age >= 59 && age <= 100) {
                return 10.5;
            }
        }
        return -1; // Return -1 for invalid input
    }
}
