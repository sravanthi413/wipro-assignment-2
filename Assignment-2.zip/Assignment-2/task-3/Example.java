public class Example {
    public static void main(String[] args) {
        // Check if there are no command line arguments
        if (args.length == 0) {
            System.out.println("No values");
        } else {
            // Join the command line arguments with a comma
            String result = String.join(", ", args);
            // Print the result
            System.out.println(result);
        }
    }
}

