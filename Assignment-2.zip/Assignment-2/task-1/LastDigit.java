public class LastDigit {
    public static void main(String[] args) {
        // Check if exactly two arguments are passed
        if (args.length != 2) {
            System.out.println("Please pass exactly two arguments.");
            return;
        }

        try {
            // Retrieve the command line arguments and convert them to integers
            int num1 = Integer.parseInt(args[0]);
            int num2 = Integer.parseInt(args[1]);

            // Check if both numbers are non-negative
            if (num1 < 0 || num2 < 0) {
                System.out.println("Please enter non-negative integers.");
                return;
            }

            // Check if the last digits of the two numbers are the same
            boolean sameLastDigit = (num1 % 10) == (num2 % 10);

            // Print the result
            System.out.println(sameLastDigit);
        } catch (NumberFormatException e) {
            // Handle the case where the arguments are not valid integers
            System.out.println("Please enter valid integers.");
        }
    }
}
