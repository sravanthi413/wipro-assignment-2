public class CheckNumber {
    public static void main(String[] args) {
        // Check if exactly one argument is passed
        if (args.length != 1) {
            System.out.println("Please pass exactly one argument.");
            return;
        }

        try {
            // Retrieve the command line argument and convert it to an integer
            int number = Integer.parseInt(args[0]);

            // Check if the number is positive, negative, or zero
            if (number > 0) {
                System.out.println(number + " is Positive.");
            } else if (number < 0) {
                System.out.println(number + " is Negative.");
            } else {
                System.out.println(number + " is Zero.");
            }
        } catch (NumberFormatException e) {
            // Handle the case where the argument is not a valid integer
            System.out.println("Please enter a valid integer.");
        }
    }
}
