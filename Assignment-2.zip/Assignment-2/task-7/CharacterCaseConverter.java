import java.util.Scanner;

public class CharacterCaseConverter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a character
        System.out.print("Please enter a character: ");
        String input = scanner.next();

        // Ensure only one character is entered
        if (input.length() != 1) {
            System.out.println("Please enter exactly one character.");
            return;
        }

        // Get the character from the input string
        char inputChar = input.charAt(0);

        // Check if the character is lowercase
        if (Character.isLowerCase(inputChar)) {
            // Convert to uppercase
            char upperChar = Character.toUpperCase(inputChar);
            System.out.println("i/p:" + inputChar);
            System.out.println("o/p:" + inputChar + "->" + upperChar);
        }
        // Check if the character is uppercase
        else if (Character.isUpperCase(inputChar)) {
            // Convert to lowercase
            char lowerChar = Character.toLowerCase(inputChar);
            System.out.println("i/p:" + inputChar);
            System.out.println("o/p:" + inputChar + "->" + lowerChar);
        }
        // If the character is not an alphabet
        else {
            System.out.println("The input character is not an alphabet.");
        }

        // Close the scanner
        scanner.close();
    }
}
