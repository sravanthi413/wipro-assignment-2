public class CheckOddEven {
    public static void main(String[] args) {
        // Check if exactly one argument is passed
        if (args.length != 1) {
            System.out.println("Please pass exactly one argument.");
            return;
        }

        try {
            // Retrieve the command line argument and convert it to an integer
            int number = Integer.parseInt(args[0]);

            // Check if the number is odd or even
            if (number % 2 == 0) {
                System.out.println(number + " is Even.");
            } else {
                System.out.println(number + " is Odd.");
            }
        } catch (NumberFormatException e) {
            // Handle the case where the argument is not a valid integer
            System.out.println("Please enter a valid integer.");
        }
    }
}

