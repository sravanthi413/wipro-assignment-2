import java.util.Scanner;

public class ColorCode {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a color code
        System.out.print("Please enter a color code (R, B, G, O, Y, W): ");
        String input = scanner.next();

        // Ensure only one character is entered
        if (input.length() != 1) {
            System.out.println("Please enter exactly one character.");
            return;
        }

        // Get the character from the input string
        char colorCode = input.charAt(0);

        // Determine the color based on the color code
        String colorName;
        switch (Character.toUpperCase(colorCode)) {
            case 'R':
                colorName = "Red";
                break;
            case 'B':
                colorName = "Blue";
                break;
            case 'G':
                colorName = "Green";
                break;
            case 'O':
                colorName = "Orange";
                break;
            case 'Y':
                colorName = "Yellow";
                break;
            case 'W':
                colorName = "White";
                break;
            default:
                colorName = "Invalid Code";
                break;
        }

        // Print the result
        System.out.println(colorName);

        // Close the scanner
        scanner.close();
    }
}
