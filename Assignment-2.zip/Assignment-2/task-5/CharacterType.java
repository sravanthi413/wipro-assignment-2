public class CharacterType {
    public static void main(String[] args) {
        // Initialize a character variable
        char ch = 'A';

        // Check if the initialized value is an alphabet
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
            System.out.println("Alphabet");
        }
        // Check if the initialized value is a digit
        else if (ch >= '0' && ch <= '9') {
            System.out.println("Digit");
        }
        // If the initialized value is neither alphabet nor digit, it's a special character
        else {
            System.out.println("Special Character");
        }
    }
}
